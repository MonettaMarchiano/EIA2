/* Aufgabe: Abschlussaufgabe
Name: Monetta Marchiano
Matrikel: 256063
Datum: 11.02.2019
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe.
Er wurde nicht kopiert und auch nicht diktiert. */
var Abschlussaufgabe_Rodelhang;
(function (Abschlussaufgabe_Rodelhang) {
    class DrawObject {
        constructor() {
        }
        draw() {
        }
        move() {
        }
        moveDown() {
        }
        moveUp() {
        }
    }
    Abschlussaufgabe_Rodelhang.DrawObject = DrawObject;
})(Abschlussaufgabe_Rodelhang || (Abschlussaufgabe_Rodelhang = {}));
//# sourceMappingURL=drawObjects.js.map